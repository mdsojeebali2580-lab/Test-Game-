(() => {
 const tg=window.Telegram?.WebApp; if(tg){tg.ready();tg.expand();try{tg.setHeaderColor('#101426');tg.setBackgroundColor('#0d1120')}catch{}}
 const initData=tg?.initData||''; const headers={'Content-Type':'application/json','X-Telegram-Init-Data':initData};
 const $=id=>document.getElementById(id); const boardEl=$('board');
 let board=[],moves=0,started=0,finished=false,me=null,adConfig=null;
 const solved=[1,2,3,4,5,6,7,8,0];
 const adjacent=(a,b)=>Math.abs(Math.floor(a/3)-Math.floor(b/3))+Math.abs(a%3-b%3)===1;
 async function api(url,opts={}){const r=await fetch(url,{...opts,headers:{...headers,...opts.headers}});const d=await r.json().catch(()=>({}));if(!r.ok)throw new Error(d.error||'Request failed');return d}
 function updateStats(){ $('points').textContent=me?.points??0;$('best').textContent=me?.best_seconds?`${me.best_seconds}s`:'—';$('games').textContent=me?.games_played??0; }
 async function refreshMe(){try{const d=await api('/api/me');me=d.user;updateStats()}catch(e){$('status').textContent=e.message}}
 async function loadLeaders(){try{const d=await fetch('/api/leaderboard').then(r=>r.json());$('leaders').innerHTML=d.leaderboard.length?d.leaderboard.map((u,i)=>`<div class="leader"><span>${i+1}</span><strong>${escapeHtml(u.first_name||'Player')}</strong><em>${Number(u.points).toLocaleString()} pts</em></div>`).join(''):'No players yet';}catch{$('leaders').textContent='Leaderboard unavailable'}}
 function escapeHtml(s){return String(s).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
 function render(){boardEl.innerHTML='';board.forEach((n,i)=>{const b=document.createElement('button');b.className='tile'+(!n?' empty':'')+(n===i+1?' correct':'');b.textContent=n||'';b.disabled=!n||finished;b.addEventListener('click',()=>move(i));boardEl.appendChild(b)})}
 function shuffle(){board=solved.slice();let prev=-1;for(let k=0;k<120;k++){const z=board.indexOf(0),opts=Array.from({length:9},(_,i)=>i).filter(i=>adjacent(i,z)&&i!==prev),n=opts[Math.floor(Math.random()*opts.length)];[board[z],board[n]]=[board[n],board[z]];prev=z}if(board.every((v,i)=>v===solved[i]))[board[7],board[8]]=[board[8],board[7]];moves=0;finished=false;started=Date.now();$('status').textContent='Tap a tile beside the empty space to move it.';$('modal').classList.add('hidden');render()}
 async function move(i){if(finished)return;const z=board.indexOf(0);if(!adjacent(i,z))return;[board[i],board[z]]=[board[z],board[i]];moves++;render();if(board.every((v,j)=>v===solved[j]))await win()}
 async function win(){finished=true;const seconds=Math.max(2,Math.round((Date.now()-started)/1000));const score=Math.max(5,Math.min(1000,1000-moves*12-seconds));$('status').textContent=`Solved in ${moves} moves · ${seconds}s`;try{const d=await api('/api/game/complete',{method:'POST',body:JSON.stringify({moves,seconds})});me=d.user;updateStats();$('win-copy').textContent=`You earned ${d.score} points in ${moves} moves (${seconds}s).`;loadLeaders()}catch(e){$('win-copy').textContent=`Puzzle solved. Score could not sync: ${e.message}`} $('modal').classList.remove('hidden');if(tg?.HapticFeedback)tg.HapticFeedback.notificationOccurred('success')}
 $('new').onclick=shuffle;$('again').onclick=shuffle;
 $('hint').onclick=()=>{const z=board.indexOf(0),opts=Array.from({length:9},(_,i)=>i).filter(i=>adjacent(i,z));const target=opts.sort((a,b)=>Math.abs(board[a]-(z+1))-Math.abs(board[b]-(z+1)))[0];$('status').textContent=`Hint: try moving tile ${board[target]}.`};
 async function setupAds(){try{adConfig=await fetch('/api/config').then(r=>r.json());if(adConfig.monetagEnabled&&adConfig.monetagZoneId&&adConfig.monetagSdkUrl){const s=document.createElement('script');s.src=adConfig.monetagSdkUrl;s.async=true;s.dataset.zone=adConfig.monetagZoneId;s.dataset.sdk=`show_${adConfig.monetagZoneId}`;s.onload=()=>{$('watch').disabled=false};s.onerror=()=>{$('watch').disabled=true;$('status').textContent='Reward ad SDK did not load.'};document.head.appendChild(s)}else{$('watch').disabled=true;$('watch').textContent='Not available'}}catch{$('watch').disabled=true}}
 $('watch').addEventListener('click',async()=>{
   if(!adConfig?.monetagEnabled||!adConfig.monetagZoneId){tg?.showAlert?.('Rewarded ads are not enabled yet.');return}
   const show=window[`show_${adConfig.monetagZoneId}`];if(typeof show!=='function'){tg?.showAlert?.('Ad is not ready. Please try again later.');return}
   const btn=$('watch');btn.disabled=true;btn.textContent='Loading…';
   try{
     const {ymid}=await api('/api/ads/start',{method:'POST',body:'{}'});
     const result=await show({ymid,requestVar:'bonus_points'});
     if(result?.reward_event_type==='valued'){$('status').textContent='Ad verified. Syncing your bonus…';}
     else {$('status').textContent='Ad completed, but no qualifying reward was confirmed.';}
     // Server-side Monetag postback is the source of truth. Never credit from a client click or Promise alone.
     for(let n=0;n<8;n++){await new Promise(r=>setTimeout(r,1500));const before=me?.points||0;await refreshMe();if((me?.points||0)>before){$('status').textContent='Bonus points credited!';break}}
   }catch(e){$('status').textContent='Ad unavailable or not verified. No points were added.'}
   finally{btn.disabled=false;btn.textContent='Watch ad'}
 });
 async function boot(){
  if(!initData){$('status').textContent='Preview mode: open this Mini App from Telegram to save scores.';$('watch').disabled=true;$('avatar').textContent='P';}
  else{try{await api('/api/session',{method:'POST',body:'{}'});await refreshMe();const u=tg?.initDataUnsafe?.user;$('avatar').textContent=(u?.first_name||'P')[0].toUpperCase()}catch(e){$('status').textContent=e.message}}
  loadLeaders();setupAds();shuffle();
 }
 boot();
})();