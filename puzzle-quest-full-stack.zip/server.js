import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import rateLimit from 'express-rate-limit';
import Database from 'better-sqlite3';
import crypto from 'node:crypto';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
const dbPath = process.env.DB_FILE || path.join(__dirname, 'data.sqlite');
const db = new Database(dbPath);
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');
db.exec(`
CREATE TABLE IF NOT EXISTS users (
 telegram_id TEXT PRIMARY KEY, username TEXT, first_name TEXT, points INTEGER NOT NULL DEFAULT 0,
 best_seconds INTEGER, games_played INTEGER NOT NULL DEFAULT 0, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 last_seen TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS ad_events (
 ymid TEXT PRIMARY KEY, telegram_id TEXT NOT NULL REFERENCES users(telegram_id),
 status TEXT NOT NULL DEFAULT 'pending', reward_points INTEGER NOT NULL DEFAULT 0,
 event_type TEXT, zone_id TEXT, estimated_price TEXT, created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
 confirmed_at TEXT
);
CREATE TABLE IF NOT EXISTS game_results (
 id INTEGER PRIMARY KEY AUTOINCREMENT, telegram_id TEXT NOT NULL REFERENCES users(telegram_id),
 moves INTEGER NOT NULL, seconds INTEGER NOT NULL, score INTEGER NOT NULL,
 created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, value TEXT NOT NULL);
`);
const getSetting = (key, fallback) => db.prepare('SELECT value FROM app_settings WHERE key=?').get(key)?.value ?? fallback;
const cfg = {
 monetagZoneId: getSetting('monetagZoneId', process.env.MONETAG_ZONE_ID || ''),
 monetagSdkUrl: getSetting('monetagSdkUrl', process.env.MONETAG_SDK_URL || ''),
 monetagRewardsEnabled: getSetting('monetagRewardsEnabled', process.env.MONETAG_REWARDS_ENABLED || 'false') === 'true',
 rewardPoints: Math.max(1, Math.min(500, Number(getSetting('rewardPoints', process.env.REWARD_POINTS || '25'))))
};

app.use(helmet({contentSecurityPolicy:false, crossOriginEmbedderPolicy:false}));
app.use(express.json({limit:'32kb'}));
app.use('/api/', rateLimit({windowMs:60_000,limit:90,standardHeaders:true,legacyHeaders:false}));
app.use(express.static(path.join(__dirname,'public')));

function safeEqual(a,b) {
 const aa=Buffer.from(String(a)); const bb=Buffer.from(String(b));
 return aa.length===bb.length && crypto.timingSafeEqual(aa,bb);
}
function validateTelegramInitData(initData) {
 if (!process.env.BOT_TOKEN || !initData || typeof initData !== 'string') return null;
 const params = new URLSearchParams(initData);
 const hash = params.get('hash');
 const authDate = Number(params.get('auth_date'));
 if (!hash || !Number.isFinite(authDate)) return null;
 const age = Math.floor(Date.now()/1000)-authDate;
 if (age < -60 || age > 86400) return null;
 params.delete('hash'); params.delete('signature');
 const dataCheck = [...params.entries()].sort(([a],[b])=>a.localeCompare(b)).map(([k,v])=>`${k}=${v}`).join('\n');
 const secret = crypto.createHmac('sha256','WebAppData').update(process.env.BOT_TOKEN).digest();
 const calculated = crypto.createHmac('sha256',secret).update(dataCheck).digest('hex');
 if (!safeEqual(calculated,hash)) return null;
 try { return JSON.parse(params.get('user') || 'null'); } catch { return null; }
}
function requireUser(req,res,next) {
 const user=validateTelegramInitData(req.get('x-telegram-init-data'));
 if (!user?.id) return res.status(401).json({error:'Open this app inside Telegram to authenticate.'});
 const id=String(user.id);
 db.prepare(`INSERT INTO users(telegram_id,username,first_name) VALUES(?,?,?)
 ON CONFLICT(telegram_id) DO UPDATE SET username=excluded.username, first_name=excluded.first_name,last_seen=CURRENT_TIMESTAMP`)
 .run(id,user.username||null,user.first_name||'Player');
 req.telegramUser={...user,id}; next();
}
function requireAdmin(req,res,next) {
 const auth=req.get('authorization')||'';
 const [scheme,encoded]=auth.split(' ');
 if(scheme!=='Basic'||!encoded) return res.status(401).set('WWW-Authenticate','Basic realm="Puzzle Quest Admin"').end();
 let raw=''; try{raw=Buffer.from(encoded,'base64').toString('utf8')}catch{}
 const i=raw.indexOf(':'); const username=raw.slice(0,i),password=raw.slice(i+1);
 if(!process.env.ADMIN_USERNAME||!process.env.ADMIN_PASSWORD||
   !safeEqual(username,process.env.ADMIN_USERNAME)||!safeEqual(password,process.env.ADMIN_PASSWORD))
   return res.status(401).json({error:'Invalid admin credentials'});
 next();
}
app.get('/api/health',(_req,res)=>res.json({ok:true,service:'Puzzle Quest API'}));
app.get('/api/config',(_req,res)=>res.json({
 monetagEnabled:cfg.monetagRewardsEnabled && Boolean(cfg.monetagZoneId && cfg.monetagSdkUrl),
 monetagZoneId:cfg.monetagZoneId,
 monetagSdkUrl:cfg.monetagSdkUrl,
 rewardPoints:cfg.rewardPoints
}));
app.post('/api/session',requireUser,(req,res)=>{
 const u=db.prepare('SELECT telegram_id,username,first_name,points,best_seconds,games_played FROM users WHERE telegram_id=?').get(String(req.telegramUser.id));
 res.json({user:u});
});
app.get('/api/me',requireUser,(req,res)=>{
 const u=db.prepare('SELECT telegram_id,username,first_name,points,best_seconds,games_played FROM users WHERE telegram_id=?').get(String(req.telegramUser.id));
 res.json({user:u});
});
app.get('/api/leaderboard',(_req,res)=>{
 const rows=db.prepare('SELECT first_name,points,games_played,best_seconds FROM users ORDER BY points DESC,games_played DESC LIMIT 20').all();
 res.json({leaderboard:rows});
});
app.post('/api/game/complete',requireUser,(req,res)=>{
 const moves=Number(req.body?.moves), seconds=Number(req.body?.seconds);
 if(!Number.isInteger(moves)||moves<1||moves>500||!Number.isInteger(seconds)||seconds<2||seconds>7200)
   return res.status(400).json({error:'Invalid game result'});
 // Score only genuine, plausible completed game submissions. No ad click/impression incentives here.
 const score=Math.max(5,Math.min(1000,1000-moves*12-seconds));
 const id=String(req.telegramUser.id);
 const tx=db.transaction(()=>{
   db.prepare('INSERT INTO game_results(telegram_id,moves,seconds,score) VALUES(?,?,?,?)').run(id,moves,seconds,score);
   db.prepare(`UPDATE users SET points=points+?,games_played=games_played+1,
     best_seconds=CASE WHEN best_seconds IS NULL OR ?<best_seconds THEN ? ELSE best_seconds END WHERE telegram_id=?`)
     .run(score,seconds,seconds,id);
 });
 tx();
 const u=db.prepare('SELECT points,best_seconds,games_played FROM users WHERE telegram_id=?').get(id);
 res.json({ok:true,score,user:u});
});
app.post('/api/ads/start',requireUser,(req,res)=>{
 if(!cfg.monetagRewardsEnabled||!cfg.monetagZoneId||!cfg.monetagSdkUrl)
   return res.status(403).json({error:'Rewarded ads are not enabled for this publisher account yet.'});
 const id=crypto.randomUUID();
 db.prepare('INSERT INTO ad_events(ymid,telegram_id,reward_points) VALUES(?,?,?)')
   .run(id,String(req.telegramUser.id),cfg.rewardPoints);
 res.json({ymid:id});
});
// Monetag postback: configure this exact URL with macros in Monetag dashboard.
// Example: /api/postback/monetag?secret=...&ymid={ymid}&event_type={event_type}&reward_event_type={reward_event_type}&zone_id={zone_id}&estimated_price={estimated_price}
app.get('/api/postback/monetag',(req,res)=>{
 if(!process.env.MONETAG_POSTBACK_SECRET || !safeEqual(req.query.secret||'',process.env.MONETAG_POSTBACK_SECRET))
   return res.status(403).send('Forbidden');
 const {ymid,event_type,reward_event_type,zone_id,estimated_price}=req.query;
 if(typeof ymid!=='string'||typeof reward_event_type!=='string') return res.status(400).send('Bad request');
 const event=db.prepare('SELECT * FROM ad_events WHERE ymid=?').get(ymid);
 if(!event) return res.status(404).send('Unknown event');
 if(cfg.monetagZoneId && String(zone_id||'') !== cfg.monetagZoneId) return res.status(403).send('Unexpected zone');
 if(!['impression','click'].includes(String(event_type||''))) return res.status(400).send('Unexpected event type');
 if(reward_event_type==='valued' && event.status!=='credited') {
   // Atomic, idempotent credit: duplicate Monetag retries cannot credit twice.
   const credit=db.transaction(()=>{
     const changed=db.prepare("UPDATE ad_events SET status='credited',event_type=?,zone_id=?,estimated_price=?,confirmed_at=CURRENT_TIMESTAMP WHERE ymid=? AND status='pending'")
       .run(String(event_type||''),String(zone_id||''),String(estimated_price||''),ymid).changes;
     if(changed) db.prepare('UPDATE users SET points=points+? WHERE telegram_id=?').run(event.reward_points,event.telegram_id);
   });
   credit();
 }
 res.status(200).send('OK');
});
app.get('/api/admin/summary',requireAdmin,(_req,res)=>{
 const users=db.prepare('SELECT COUNT(*) n FROM users').get().n;
 const games=db.prepare('SELECT COUNT(*) n FROM game_results').get().n;
 const pending=db.prepare("SELECT COUNT(*) n FROM ad_events WHERE status='pending'").get().n;
 const credited=db.prepare("SELECT COUNT(*) n FROM ad_events WHERE status='credited'").get().n;
 const totalPoints=db.prepare('SELECT COALESCE(SUM(points),0) n FROM users').get().n;
 res.json({users,games,pendingAds:pending,creditedAds:credited,totalPoints,recentUsers:db.prepare('SELECT telegram_id,first_name,username,points,games_played,last_seen FROM users ORDER BY last_seen DESC LIMIT 30').all(),recentAds:db.prepare('SELECT ymid,telegram_id,status,reward_points,event_type,estimated_price,created_at FROM ad_events ORDER BY created_at DESC LIMIT 30').all()});
});
app.get('/api/admin/config',requireAdmin,(_req,res)=>res.json(cfg));
app.post('/api/admin/config',requireAdmin,(req,res)=>{
 const enabled=Boolean(req.body?.monetagRewardsEnabled);
 const zone=String(req.body?.monetagZoneId||'').trim();
 const sdk=String(req.body?.monetagSdkUrl||'').trim();
 if(sdk && !/^https:\/\/[a-z0-9.-]+\/[a-z0-9_./-]+\.js(\?.*)?$/i.test(sdk))
   return res.status(400).json({error:'SDK URL must be a valid HTTPS JavaScript URL from Monetag.'});
 cfg.monetagRewardsEnabled=enabled; cfg.monetagZoneId=zone; cfg.monetagSdkUrl=sdk;
 const save=db.prepare('INSERT INTO app_settings(key,value) VALUES(?,?) ON CONFLICT(key) DO UPDATE SET value=excluded.value');
 const persist=db.transaction(()=>{save.run('monetagRewardsEnabled',String(enabled));save.run('monetagZoneId',zone);save.run('monetagSdkUrl',sdk)});
 persist();
 res.json({ok:true,config:cfg});
});
app.get('/api/admin/export.csv',requireAdmin,(_req,res)=>{
 const rows=db.prepare('SELECT telegram_id,username,first_name,points,games_played,best_seconds,created_at,last_seen FROM users ORDER BY points DESC').all();
 const cols=Object.keys(rows[0]||{telegram_id:'',username:'',first_name:'',points:'',games_played:'',best_seconds:'',created_at:'',last_seen:''});
 const csv=[cols.join(','),...rows.map(r=>cols.map(c=>'"'+String(r[c]??'').replaceAll('"','""')+'"').join(','))].join('\n');
 res.type('text/csv').attachment('puzzle-quest-users.csv').send(csv);
});
app.get('/admin',requireAdmin,(req,res)=>res.sendFile(path.join(__dirname,'public','admin.html')));
app.use((err,_req,res,_next)=>{console.error(err);res.status(500).json({error:'Internal server error'});});
const port=Number(process.env.PORT||3000);
app.listen(port,()=>console.log(`Puzzle Quest listening on :${port}`));
